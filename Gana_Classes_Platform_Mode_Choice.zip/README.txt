Gana Classes - Educational Platform Starter
===============================================
This is a visual starter package for the Gana Classes educational platform.

Pages included:
1. Splash / Welcome
2. Home
3. Primary grades
4. Subjects
5. Lessons
6. Quizzes
7. Student profile

Brand:
- Pink + white
- Soft purple accents
- Friendly educational style

This package is a DESIGN/PROTOTYPE starter, not a finished Google Play APK.
